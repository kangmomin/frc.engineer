# 전체 감사 이슈 수정: 독립 사전 리뷰

검토 범위: `/tmp/frc-remediation-_xwlt3m5/spec.md`, `docs/reviews/20260906-project-audit.md`, 실제 Go 생산자·저장·RTC 경로와 React/Zustand 소비자. 읽기 전용 사전 리뷰이며 제품 코드를 수정하거나 실행 검증을 통과했다고 주장하지 않는다. 외부 리뷰 CLI·추가 에이전트는 사용하지 않았다.

**결론:** 계획의 수정 범위·우선순위는 타당하다. 사용자가 승인한 전체 이슈 수정 범위에서 구현을 진행할 수 있다. 아래 계약을 구현 계획에 명시하면 저장·세션·표시 변경 간 재작업과 새로운 혼합 오류를 줄일 수 있다. 기존 seal/2시간 hold/boot·pair sweep/피트로스/Windows snapshot/bounded 종료 정책은 유지한다.

## 먼저 고정할 계약과 구현 순서

1. **N01·N02·K04(상):** 계산 종료성, 사용자 Leave의 로컬 종료 시점, reliable 응답의 유한 대기를 먼저 고친다. 방송 drop 정책은 유지한다.
2. **N14·K01·N03·N08·C01의 생산자 계약(상):** UID 문자열, 세션 유형·게임/차량 형식·실측 참가 정보, 유효 best/완료 랩 관측을 생산자에서 정의하고 모든 copy helper까지 전파한다.
3. **N05·N06·N07·K02·K05(상):** 완료 랩과 관측 값의 출처를 보존한다. 재시작 merge는 원본 provenance를 읽고 값을 합친 후 provenance를 OR 해야 한다.
4. **N09·N10·N11·N12·N13·C01(상):** 공통 identity와 replay 전용 파생 데이터를 모든 소비자에 연결한다. qualifying 정렬·행·cutoff가 같은 순위를 보도록 맞춘다.
5. **N04·N15·K03·K06·K07(중~상):** 얕은 결과 DTO, 시간 정렬, 업로드 진행성, restart 성공과 요청 취소를 연결한다. K07은 K04 send helper에 context-aware wait를 더하는 순서가 적합하다.
6. **I01·I02·I03·I04(중~상):** 의존성·툴체인 검증은 병행하되 실제 Windows 재빌드와 CI가 같은 버전을 사용하도록 마지막에 확인한다. I03 유지 결정은 현재 Spec에 명시되어 있으므로 연결·유효성·track 0을 함께 복구한다.

## 핵심 교정 사항

### 세션 identity와 cache: N14·K01·N03·N13

- `SessionUID`는 Go `uint64`다. 새 JSON/TypeScript identity는 **문자열**이어야 한다. JavaScript number로 보내면 2^53 이상 UID가 충돌할 수 있다. 기존 아카이브에 UID가 없는 경우의 legacy fallback은 별도로 유지한다.
- `PitwallManager.noteSessionUIDLocked`는 `UpdateSession`뿐 아니라 다른 모든 packet와 `RecordPenalty`에서 먼저 호출된다. 새 Motion/Telemetry/PENA가 첫 Session보다 먼저 도착하는 경우에도 이전 `session`, `motion`, `telemetry`, `carTelemetry2`, `motionEx`, `carDamage`, `carSetups` 및 파생 cache를 쓰지 않게 해야 한다. 새 Session 전 metadata를 이전 트랙으로 대신하지 않는다. UID 0을 경계로 보지 않는 기존 규칙은 유지한다.
- **`buildStateLocked`의 TrackMap 분기(기준 약 585행)에도 sessionHistory/tyreSets/peakActiveCars reset이 남아 있다.** UID reset이 lastTrackID=-1로 만든 뒤 새 history가 먼저 도착하면 첫 BuildState가 새 cache를 다시 지운다. reset을 입력 경계로 모으고 TrackMap 발행은 map 재전송만 담당하도록 정리해야 한다.
- `raceMetaStore.ingest`는 현재 `drivers.length === 0` 검사 뒤에 identity를 확인한다. 새 세션의 빈 프레임에서도 이전 history·선택 상태가 남지 않도록 key 확인을 먼저 한다. 일시 disconnect에서 동일 UID를 새 세션으로 만들지 않는다. `lapHistoryStore`는 raceMeta 구독 순서를 의존하므로 공통 key 또는 기존 epoch 순서를 실제 tracker 검사로 확인한다.
- qualifying 상태 key에는 session UID뿐 아니라 **segment와 player identity**를 포함한다. 같은 UID 안 Q1→Q2, player index 변경, 같은 index의 참가자 변경, 2→1 rewind 모두 reducer와 previous-frame ref를 함께 초기화해야 한다. reset effect와 tick effect가 같은 렌더의 이전 상태를 잠깐 노출하지 않는지도 확인한다.
- Recorder에는 UID/트랙/track length가 함께 필요하다. lap 감소·동일 lap 내 거리 역행·UID/track 변경에서 buffer를 폐기하고, `lap+1`과 정상 결승선 거리 wrap 및 충분한 거리 coverage를 모두 확인한 뒤 교체한다. 101점은 높은 샘플링 주파수의 500m 부분 랩일 수 있으므로 point count는 완주 근거가 아니다. 종료 직전 경계 프레임도 검사해야 한다.
- `UpdateMotion`은 recorder 호출을 pm lock 밖으로 옮긴다. reset 메서드만 별도로 호출하면 오래된 캡처가 reset 후 recorder에 다시 들어갈 여지가 있으므로 전달된 identity를 recorder가 검증하거나 producer 호출 순서를 보장한다. 기존 맵의 파일·메모리 두 곳 모두 보존 여부를 검사한다.

### 유효 best·sector·컷오프: N10·N11·N12·C01

- `getQualifyingBestLapTime`의 무조건 lastLap fallback은 제거 대상이다. `lapInvalid=false`는 **새 현재 랩** 기준이라 마지막 랩 유효성의 증거가 아니다. 유효 best를 전송하거나, fallback을 유지한다면 완료 랩의 알려진 validity와 source를 함께 보내야 한다. `best=0`에서 unknown과 known-no-valid-lap을 구분한다.
- 공식 best는 브라우저의 낮은 임시 값보다 **우선하고 교정할 수 있어야 한다**. `min(official, provisional)`이면 invalid 20초 값이 official 30초보다 영구히 우선하여 N12가 남는다. 공식 값 도착 전 fallback은 완료된 유효 랩 또는 검증된 해당 섹터에 한한다.
- `packets.LapHistoryData.LapValidBitFlags`는 lap=0x01, S1=0x02, S2=0x04, S3=0x08이다. lap-valid와 sector-valid는 다른 정보이므로 공식 sector를 whole-lap validity 하나로 과도하게 삭제하지 않는다. 현재 Go best helper와 buildState의 중복 구현도 동일 계약으로 맞추면 drift를 줄일 수 있다.
- 현재 `sortQualifyingDrivers`는 hasLap 비교를 knockout 그룹보다 먼저 한다. Q2/Q3에서 탈락자가 이전 segment의 best를 가진 채 남고 진출자는 아직 기록이 없으면 탈락자가 먼저 올 수 있다. **진출/탈락 그룹 → 그룹 내 유효 best/official position** 순으로 판단하고 행의 pos·cutoffWatch의 myPos·목표 이름을 동일 정렬에 맞춘다. position 0을 safe로 분류하지 않는다.
- 보고서의 표준 fixture는 20→15→10, 22→16→10, 24→17→10이다. **UDP capacity=24, `drivers.length`, 현재 `NumActiveCars`를 무조건 초기 grid 수로 보지 않는다.** 현재 BuildState는 참가 packet가 없으면 24개의 기본 driver를 만들며 peakActiveCars는 세션 reset 후 사라진다. Q2 중간 접속의 16대와 Q1 커스텀 16대를 구분할 metadata/근거가 필요하다.
- Session parser는 formula byte를 현재 생략한다. F1/F2·custom·short·one-shot 판정에 필요한 필드를 wire spec에서 확인해 전달하고, 확정할 근거가 없는 형식은 기존 noCutoff로 degrade한다. 20→15 상수를 단순히 format==2026 ? 16 : 15로 바꾸면 24대·custom/F2가 틀릴 수 있다.
- N11은 safe 선수는 첫 탈락자, drop 선수는 마지막 진출자를 기준으로 계산한다. 동률은 먼저 기록한 드라이버 우선인 만큼 `Need 0.000s` 대신 strictly-better 요구를 표현한다(예: MS 정밀도에서 +1ms 또는 동률 우선 규칙을 드러낸 문구). 목표 위치·code·margin tile도 함께 바꾼다.

### Replay 출처와 재시작: N08·N09·K05

- `copyPitwallForReplay`와 `copySessionInfo`를 각각 필드 나열로 유지하면 새 UID/grid metadata도 재누락될 수 있다. 스칼라 struct copy 후 slice/pointer를 deep-copy하고, `copyPitwallForReplay`에서 공통 helper를 호출하는 최소 변경을 권한다. source mutation 뒤에도 저장 프레임이 바뀌지 않는 검사와 600/1080 clock 보존 검사를 함께 한다.
- Replay의 timestamp는 `recordReplayFrame(..., now.UnixMilli(), ...)`에서 온 **wall-clock ms**다. K05를 lap number 또는 sessionTime 기준으로 단순 병합하지 않는다. 동일 stable ID/UID 내 timestamp 정렬·정확한 중복 기준·겹침 우선순위·새 replay가 nil인 경우 보존을 명시한다. 반복 checkpoint merge가 멱등이어야 한다.
- 새 프로세스 재시작 후 같은 랩에서 재수집한 데이터와 단순 duplicate timestamp를 구분한다. 저장 상한을 둘 경우 이미 승인된 장시간 recording을 임의로 잘라 silent data loss를 만들지 말고 명시적인 cap/보존 정책을 둔다. trackMap/session metadata는 next가 없으면 prev를 보존하되 다른 session의 값을 혼합하지 않는다.
- N09의 live tracker replay skip은 유지한다. `PitWallView`, `DriverDetailModal`, `QualifyingView` 및 raceMeta 소비자가 **선택한 replay와 해당 frame index까지의 전용 history/meta**를 읽게 한다. 데이터가 없으면 빈 표시가 허용되며 live history fallback은 허용하지 않는다.
- forward seek는 건너뛴 과거 프레임을 ingest하거나 prefix 결과를 사용하고, rewind와 같은 랩 내 역방향 seek는 재구축해야 한다. 단순 lap 감소 감지만으로는 같은 lap에서 미래 best/sector가 남는다. archive ID를 provenance key에 넣어 같은 track/sessionType/lap/index의 다른 리플레이가 충돌하지 않게 한다. replay 종료 시 live store를 원래 상태로 복구한다.

### 비동기 제어: N02·K04·K06·K07

- N02는 leave 진입에서 membership/media operation을 동기 무효화하고 track/peer 정리를 ACK보다 먼저 한다. `joinInternal`, `createGroup`, unsolicited `intercom_joined`, 진행 중 getUserMedia/replaceInput/rebuildMedia, 250ms resume timer, 늦은 leave ACK가 새 join을 지우는 경우까지 세대로 차단한다. `clearMembership()`만 앞당기면 unsolicited joined가 payload로 credentials를 재구성하므로 leaving 이후 차단 장치가 추가로 필요하다.
- K04는 `SendTo`만 고치면 synchronous request의 `sendToIfCurrent` 경로에 응답 유실이 남는다. 두 경로에 유한 대기와 오류 기록을 적용하고 `BroadcastAll/PerPeer/Fast`의 wait=0을 유지한다. 전송 대기 중 pm 전역 lock을 잡지 않는다. 경합 없는 oversized payload는 즉시 실패해야 한다.
- K06은 answer 전송 완료만으로 ICE 성공을 단정하지 않는다. **현재 pc+negotiation generation**에 대해 answer 적용 이후 connected/open 상태, ICE connected/completed 또는 새 reliable ping/응답을 성공 근거로 처리하고 stage watchdog·reconnect UI·grace를 함께 해제/완료한다. stale promise/event가 새 negotiation의 timer를 해제하지 못하게 한다. `connectionState`가 connected로 유지되는 실제 경로를 검사한다.
- K07 cancel은 requestId만 전역 key로 쓰지 말고 **peer/connection generation/requestId**로 범위를 제한한다. handler가 stream goroutine 시작 전에 cancel 등록을 완료해야 즉시 abort를 놓치지 않는다. 구 요청 cleanup이 같은 key의 새 요청을 삭제하지 않도록 compare-current 정리를 사용한다.
- `WalkReplay` frame callback, batch send, buffered wait에 context 취소를 전달하고 cancel/disconnect/shutdown 뒤 terminal chunk도 새로 보내지 않는다. 이미 SCTP에 들어간 바이트를 되돌릴 수 없다는 사실과 이후 생성/전송 중지를 구분한다. 현재 `SendToBuffered`는 peerID로 매번 channel을 찾으므로 재연결 뒤 오래된 stream이 새 channel에 붙지 않게 한다.

### 분석·업로드·나머지 개선: N04·N05·N06·N07·N15·K02·K03·I01~I04

- N05/N06: 이전 lap의 invalid를 OR 누적하고 **+1 완료 경계 전** S1/S2 snapshot을 저장한다. minute part를 포함한 uint32/int ms를 쓴다. +N 점프·rewind는 같은 완료 처리로 통과시키지 않는다. 마지막 랩을 숫자 증가 없이 멈추는 경우 및 SessionHistory의 공식 보정 가능성도 검토한다. `fastestLap`/comparison을 실제 valid 결과와 연결한다.
- N07: lap 시작/완료 시간과 해당 시점 이하의 tyre snapshot으로 매칭하고 미래 snapshot fallback을 제거한다. lap 경계 직후 compound가 바뀌면 이전 lap에 새 tyre가 붙지 않아야 한다. sessionTime rewind가 가능한 로그라면 단순 시간 정렬로 다른 flashback 세대를 섞지 않는다.
- K02: 현재 `mergeDebrief`는 `mergePrivateCapture` 전에 실행하므로 원본 provenance를 볼 수 있다. CarStatus→compound+age, CarDamage→average+peak wear, TyreSets→set wear/lifespan/usable life/remaining을 출처 그룹별로 복구하고 next에서 관측한 0을 prev 값으로 덮지 않는다. 동일 문제가 penalties의 LapDataObserved에도 있으므로 그 그룹을 같이 확인한다. Upload의 optional 포인터 결과까지 검사한다.
- K03: durable 영구 거절 상태 또는 durable 진행 위치가 필요하다. 메모리 cursor만 두면 재시작마다 앞 20건에서 멈춘다. 401/403/409/429/network/5xx는 기존 retryable/abort 정책을 유지하고 영구 거절로 낙인찍지 않는다. seal을 해제하거나 machine-global 업로드 정책을 account별로 바꾸지 않는다. 수동 재시도 허용 여부를 명시한다.
- N04: latest의 memory/disk 두 경로가 공통 요약 projection을 써야 한다. replay뿐 아니라 private capture/큰 incidents/detail을 결과 UI에서 실제로 쓰는지 확인해 최소 DTO로 만든다. 메모리 summary 원본을 mutate하지 않고 실제 handler를 httptest로 검증한다. disk에서 전체 replay를 decode한 뒤 지우는 방식을 계속 쓰면 전송량은 줄어도 폴링 decode 비용은 남는다.
- N15: directory 전체 문자열 대신 파싱 timestamp 내림차순, 동률 directory 등 결정적 tie-break를 쓴다. 파싱 실패 항목 처리도 기존 목록 허용 범위 안에서 정한다.
- I01/I02: audit advisory의 fix 버전을 기준으로 현재 공식 패치 여부를 확인하고 Go mod/toolchain/CI/실제 sender artifact를 맞춘다. govulncheck JSON의 exit 0을 clean으로 해석하지 않는다. 전용 PostgreSQL main/upgrade DB에서 skip을 gate로 검사하고 기존 browser script가 실제 production hook/React를 실행하는지 확인한다. Windows runner는 최소 실행/종료/재시작을 검사하며 Linux cross-build를 native 검증으로 보고하지 않는다.
- I03: track 0은 Australia다. sentinel을 -1/명시 여부로 바꾸고 Session 수신 후 SetTrackID가 초기화에 지워지지 않게 순서를 고정한다. 유효 lap·minute sector·새 세션 reset과 저장 callback을 통합 검증한다.
- I04: 현재 화면 존재와 남은 품질 문제를 구분하고 역사적 audit 보고서는 보존한다.

## 구현 후 반드시 확인할 회귀 경계

- N01: Inf/NaN/MaxFloat32 ±입력의 Parser→Processor 종료와 정상 신호 유지.
- N02/K04/K06/K07: 지연 ACK+중간 snapshot+late getUserMedia, 실제 열린 Pion channel의 20ms mutex 경합, Chrome connected 유지 restart 후 12초 초과 관찰, chunk 중 cancel 후 다음 요청과 peer 재연결.
- N03/K01/N14: 새 UID 첫 packet 종류별 cache 없음, 새로운 history가 첫 BuildState 후에도 남음, 같은 형식 lap 1→lap 1 새 UID reset 및 동일 UID transient reconnect 유지, track 파일·메모리 모두 보존.
- N05/N06/N07: 무효 80s와 유효 90s, 70/40/40s sector, Soft/Soft/Medium, 동일 lap time 반복 완료, jump/rewind/terminal lap.
- N08/N09/K05: metadata clock/UID copy, 다른 archive 같은 car index, forward seek/같은 lap rewind/live 복귀, 저장 [1000,1500] + [2000] 및 반복 merge·nil next replay.
- N10/N11/N12/N13/C01: invalid last→best 없음, official 30s가 임시 20s 교정, Q1→Q2 직접 2→1, player 교체, 표준 20/22/24·F2/short/unknown grid, Q2 active no-lap vs eliminated valid lap, tie와 position 0.
- K02/K03/N04/N15: 출처 그룹의 관측 0과 미관측 값 구분, 첫 20건 영구 거절 후 21번째 정상 건이 재시작 후에도 진행, latest 실제 memory/disk 응답이 replay 크기에 비례하지 않음, UID 역순 timestamp 목록.
- DTO 확장 후 기존 **24대+최대 2,000-point map ≤256KiB / steady ≤128KiB** 및 RPC/replay chunk 크기 검사를 재실행한다. 기존 bug-observation PASS를 반대로 수정한 regression assertion과 구분해서 기록한다.

## 리뷰 상태

Pre-review: 핵심 코드 경로 대조 완료. Layer: Presentation의 source/identity, Service의 bounded lifecycle, Repository의 merge/provenance 구분이 위 교정으로 충족 가능. Simplicity: DTO·기존 helper·공통 key 중심의 수정으로 충분하며 전면 리팩토링은 필요하지 않다. 제품 요구를 새로 정해야 하는 custom grid·cap 정책은 근거 없으면 unknown/기존 정책으로 처리한다. 검증 결과는 구현 담당자의 실제 실행 결과로 별도 보고해야 한다.

## 후속 코드 확인으로 보강한 항목

- **I03 초기화 순서:** `SetTrackID`만 Session 경로에 추가하면 `DeltaCalculator.Update`의 UID 변경 분기가 방금 읽은 best를 다시 지운다. 세션 초기화 → track 지정/load → lap ingest 순서를 하나의 계약으로 만들어야 한다. track 변경 시 load가 nil/error여도 이전 트랙 best를 먼저 지워야 한다. `LapTelemetry.Sector1MS/2MS/3MS`와 `SetLapTimes`는 현재 uint16이므로 70초 sector의 분 합산 지원은 저장 모델까지 uint32로 넓혀야 한다.
- **I03 producer cache:** `Processor.latestTelemetry/latestLapData/latestHeader/latestPlayerCT2`는 PitwallManager와 별도의 dashboard cache다. UID 변경 시 이 쌍도 일관되게 비우지 않으면 새로 활성화한 delta 저장에 이전 telemetry/lap이 섞일 수 있다. delta update를 rate-limited dashboard builder에서만 하는 현재 구조가 invalid flag/완료 경계를 놓치는지 확인하고 필요한 lap 관측은 packet 경계에서 한다.
- **I02 DB 격리:** 실제 env는 `PLATFORM_TEST_DATABASE_URL`, `PLATFORM_UPGRADE_TEST_DATABASE_URL`이다. `internal/platformsvc`와 `cmd/platform` 양쪽이 공통 DB를 TRUNCATE하므로 env를 설정한 `go test -race ./...`는 package 병렬 실행을 주의해야 한다. `-p 1` 또는 package별 독립 DB를 사용하고 upgrade DB는 별도로 둔다.
- **I02 실제 browser 진입점:** `web/scripts/test-webrtc.mjs`는 실제 Chrome+Vite에서 `useWebRTCDataChannel.browser.tsx`와 `archiveRemote.browser.tsx`를 실행한다. 이 suite의 production hook 경로에 K06/K07을 추가하고, N02를 포함하려면 실제 runtime/media suite와 fake-media Chrome flags를 명시적으로 추가해야 한다. 현재 전체 45초 timeout은 기존 suite와 12초 watchdog 관찰을 합친 실행량에 맞춰 검토한다.
- **N07 로그 시간 근거:** `packetEnvelope`에 `sessionTime`뿐 아니라 wall-clock `ts`와 `frame`도 존재한다. 재현된 단순 세션에서는 sessionTime matching으로 충분하지만 rewind capture를 지원할 때는 기록 순서/세대와 함께 써야 한다. 분리된 파일을 각각 sessionTime으로만 정렬하면 flashback 이전 미래 snapshot이 새 과거 lap에 매칭될 수 있다.
