# All audit issues remediation plan
Baseline: 84790bf5b7a8ae12c1706ed9a8d98ef9e79b70ef (v4.53.0).
User authorizes fixing every reported issue. Preserve all existing untracked documents and the historical audit report. No release/commit/push requested in this remediation.
Full scope: N01-N15, C01, K01-K07, I01-I04 in docs/reviews/20260906-project-audit.md.

Plan and difficulty:
1. Guard dynamics calculations and immediate intercom Leave; bounded reliable RPC replies (high).
2. Authoritative session UID/metadata; reset Go caches/recorder and browser stores; conserve completed lap values and official history (high).
3. Offline analysis validity/sector/minutes/time-based tyres and timestamp ordering (medium).
4. Replay metadata, restart merging, isolated playback-derived history, cancel propagation and successful ICE restart (high).
5. Lightweight latest result API and fair persistent upload backlog progress (medium/high).
6. Patch Go/Pion/npm/Electron; align toolchain, DB/browser/Windows/security CI (high).
7. Restore supported delta persistence semantics and update feature scope docs (medium).
8. Item-by-item regression coverage, full build/tests/audits, Windows cross-build and available actual browser integration. Document external/hardware limits honestly without claiming unverified checks passed.

Pre-review requested: one independent fresh-context reviewer, read-only. Review this plan against real code and suggest concrete corrections/ordering, especially cross-layer contracts, replay provenance and session validity. Do not modify source. Return bounded feedback with applicable pitfalls and verification. Do not spawn external CLIs or further agents.

Test policy: turn audit repros into actual regression tests linked to production implementations. Existing bug-observation assertions must be inverted/rewritten. Preserve accepted policies listed in the audit. DTO changes must test 24-car + max trackmap <=256 KiB / steady <=128 KiB.
