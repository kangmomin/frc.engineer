# 감사 이슈 수정 후 독립 후속 리뷰

범위: 이번 worktree diff와 추가 회귀 검사. 특히 N09 replay provenance/prefix, C01 observed grid, K06 recovery proof, K07 RequestTransport cancellation, I03 Delta reset/load/save 순서를 검토했다. 제품 파일을 변경하지 않고 `/tmp/frc-remediation-_xwlt3m5`의 임시 Chrome 하네스·Go overlay만 작성했다. 외부 CLI 리뷰어·추가 에이전트는 사용하지 않았다.

## 확인한 결함과 정책 누락

### F1 · P2 · live/replay의 독립 epoch 충돌로 화면 내부 이력은 여전히 혼합됨 — N09

리뷰 시점의 `BroadcastView`는 전용 replay raceMeta를 읽도록 바뀌었지만 `useBattleEngine` 초기화 key는 여전히 `trackId|sessionType|totalLaps`와 숫자 `epoch`다. 두 독립 store는 같은 숫자를 가질 수 있다. 실제 `resetRoom → 첫 live 세션`과 `첫 replay prefix`가 모두 epoch=2다. 따라서 같은 트랙·형식·랩수·car index의 replay로 전환해도 live 배틀 이력이 초기화되지 않는다. `PitWallView`의 `[epoch]` 의존 openDriverIdx 닫기도 동일한 충돌에 노출된다.

실제 Chrome+React+production tracker/hook으로 재현했다. live에서 4.2초간 gap 900→500ms를 만든 뒤 replay 첫 1프레임(gap 700ms)으로 전환했다.

```json
{
  "liveEpoch": 2,
  "replayEpoch": 2,
  "live": { "trend": "closing", "ratePerLapMs": 8581.64 },
  "replayFirstFrame": { "trend": "closing", "ratePerLapMs": 4240.28, "predictionText": "Pressure building" }
}
```

리플레이에는 한 프레임뿐이므로 추세 baseline이 없으며 unknown/building read여야 한다. prefix용 랩·섹터 저장소 자체는 분리됐지만 뷰 내부 상태에는 표시 출처 key가 추가로 필요하다.

재현: `node /tmp/frc-remediation-_xwlt3m5/followup-browser.mjs` (`/workspace/frc.engineer/web`에서 실행). 하네스는 production `useBattleEngine`과 `useDisplayedRaceMeta`를 실제 React에서 사용한다. 반환값은 결함 관측 결과이며 PASS assertion이 아니다. 구현 담당자는 공통 displayed source key로 수정 및 회귀 검사를 추가하겠다고 응답했다.

### F2 · P2 · Delta가 선수 전환을 랩 완료로 받아들여 다른 선수의 trace를 저장함 — I03

리뷰 시점 `DeltaCalculator`는 SessionUID/track만 추적하고 Header.PlayerCarIndex는 무시한다. 같은 UID에서 car 0의 lap 1을 관측한 뒤 car 1의 lap 2로 전환하면 car 1의 LastLapTime을 car 0이 완료한 랩으로 채택한다. 새로 활성화된 저장 callback으로 서로 다른 선수의 시간/trace가 파일에 영구 저장된다. Processor의 `latestTelemetry`도 같은 UID 내 선수 교체만으로는 초기화되지 않아 첫 lap packet과 이전 선수 telemetry가 연결될 수 있다.

실제 Go production calculator overlay에서 아래 정상 유한 입력을 사용했다.

1. player 0, lap 1, 10m/0.1초, speed 300.
2. player 0, lap 1, 4990m/89초, S1/S2=30초, speed 300.
3. 동일 UID의 player 1, lap 2, 10m, lastLap=80초, speed 200.

기대: 선수 변경 후 새로운 현재 랩의 완주를 관측하기 전에는 저장하지 않는다.

실제 실패 결과:

```text
player switch persisted mixed lap: lap=80000 sectors=30000/30000/20000
points=[{LapDistance:10 LapTime:100 Speed:300} {LapDistance:4990 LapTime:89000 Speed:300}]
```

실행: `go test -overlay=/tmp/frc-remediation-_xwlt3m5/delta_followup_overlay.json ./internal/telemetry -run TestReviewDeltaPlayerSwitchCannotCompletePreviousPlayerLap -count=1`. 정상 불변식을 검사하며 리뷰 시점에 FAIL했다. 원본은 `delta_followup_test.go`, overlay는 `delta_followup_overlay.json`이다. 선수 전환 시 현재 lap과 cached player telemetry 쌍을 초기화해야 한다. 저장된 같은 트랙 reference의 유지/재조회는 이와 별도 정책이다.

### F3 · P2 · Result Only에서도 원시 best-lap trace를 저장하도록 새로 활성화됨 — I03

새 Sender callback은 `cfgSaveFiles`만 검사한다. 따라서 기본 `resultOnly`에서도 `track_*_best_lap.json`에 DataPoints(속도·스로틀·브레이크 등)를 저장한다. 이는 Driver Pack의 현재 Result Only 문구 `Save race result summary only.` 및 `internal/config/runtime.go`의 minimal race-result 정의와 맞지 않는다. 레거시 server callback의 복구와 별개로 Sender에서 새 파일 종류가 활성화된 부분이다.

이는 조건문과 실제 SaveBestLap에 전달되는 `LapTelemetry` 모델을 대조한 코드 경로 확인이다. Driver Pack 클릭→실제 파일 생성까지 별도 통합 실행하지 않았다. 구현 담당자는 Sender의 저장 callback을 `saveFiles && dataStorageMode == advanced`로 제한하고 기존 server의 명시적 legacy callback을 유지하겠다고 응답했다.

### F4 · P2 · 일반 Event가 첫 새 UID이면 PitwallManager 경계 관측이 누락됨 — K01/N14

리뷰 시점 Processor는 새 UID에서 dashboard/Delta cache를 비웠지만 PitwallManager에는 각 packet별 Update와 PENA의 RecordPenalty만 UID를 전달했다. SSTA/SEND 같은 일반 Event는 새 UID를 PM에 전달하지 않아 이전 session/motion/telemetry가 유지된다. 이후 같은 processPacket에서 BuildState와 새 UID의 replay capture가 이루어지면 오래된 PitwallState를 새 replay로 묶을 수 있다.

이는 `processPacket → handleEventPacket → HasData/BuildState/recordReplayFrame`의 직접 호출 경로를 대조한 확인이며 추가 overlay를 실행하기 전에 구현 담당자가 누락을 인정했다. 담당자는 이전 세션 finalize 이후 모든 packet별 feed 전에 공통 PM header 관측을 호출하고 SSTA-first 회귀에서 PM cache도 검사하도록 수정하겠다고 응답했다.

## 지정 범위에서 추가 결함을 확인하지 못한 부분

- **N09 prefix 저장소:** archive ID/frames 참조/index 감소에 재구축하고 forward seek는 생략된 프레임까지 ingest한다. lap history와 qualifying sector는 live store로 fallback하지 않는다. F1의 별도 뷰 내부 상태만 남았다.
- **C01 observed grid:** 공식 parser의 formula를 전달하고, formula 0/13과 실제 관측 20/22/24만 standard cutoff로 사용한다. reduced Q2/unknown/F2/short 계열은 unknown으로 내려간다. 이 보수적 지원 정책 안에서 새로운 구체적 결함을 확인하지 못했다. 실제 F1 26 커스텀 그리드 송신 순서를 검증했다고 주장하지 않는다.
- **K06 recovery proof:** 현재 pc/negotiation의 answer 이후 실제 reliable ping과 ICE connected/completed를 확인한다. `connectionState` 이벤트가 없는 재시작을 production Chrome 테스트에 추가했다. 코드와 추가 검사를 대조했으며 운영 NAT/TURN/Pion 조합을 이 리뷰에서 실행하지 않았다.
- **K07 cancellation:** transport는 한 reliable channel에 묶이고 peer context가 request context의 부모다. BeginRequest 등록이 goroutine보다 먼저 이루어지며 old cleanup은 replacement request를 삭제하지 않는다. cancel은 decoder/Windows snapshot 복사/buffered wait까지 이어진다. 추가 결함은 확인하지 못했다.
- **I03 reset/load:** Session observe → track 지정/load → lap packet별 ingest 순서는 기존 첫 Update의 load 삭제 문제를 고쳤다. 저장 sector가 uint32로 확장됐으며 synchronous callback은 d.mu 밖에서 호출된다. F2의 선수 변경 경계와 F3의 Sender 모드 gate가 추가로 필요하다.

## 상태와 정리

Chrome 하네스는 실행 종료 시 자신의 browser/Vite server/profile을 정리했다. 제품 파일은 수정하지 않았다. 임시 재현 원본은 구현 담당자가 회귀 검사로 옮길 수 있도록 위 경로에 남겼다. F1~F4가 후속 수정됐다는 최종 판단은 해당 수정 후 실제 검사 결과를 확인해야 하며, 이 문서는 최초 후속 리뷰 시점의 관측을 보존한다.

## F1~F4 최종 수정 재검토

최종 worktree의 해당 네 수정과 추가 회귀 검사만 다시 검토했다. **F1~F4는 모두 해소됐으며, 이 범위에서 추가로 재현 가능한 결함이나 누락은 발견하지 못했다.** 위의 실패 관측은 수정 전 기록으로 보존한다.

| 항목 | 수정 확인 | 독립 검증 |
|---|---|---|
| F1 · 표시 출처 | 공통 `useDisplayedSourceKey`가 room generation, session identity, live/replay 구분, archive source ID, replay generation, metadata epoch를 구분한다. Broadcast 결과와 Pitwall 선택은 해당 identity가 달라진 첫 render에서 차단한다. Qualifying도 공통 key를 사용한다. Drawer는 실제 로드된 `replaySourceId`와 선택 ID가 같을 때만 기존 frames를 적용한다. | production tracker/hook을 쓰는 임시 Chrome 검사에서 **동일 UID 및 양쪽 epoch=2**인 live→replay에도 key가 달랐고, live의 closing 8583.69ms/lap이 replay 첫 프레임의 `unknown`/`building read`로 초기화됐다. 동일 frames를 source A→B로 바꿔도 key가 변경됐다. 추가된 실제 Broadcast/Pitwall 화면 검사도 독립 실행하여 live→replay의 추세 초기화, modal 닫기, archive A→B modal 닫기, replay 종료 시 초기화를 확인했다. Drawer의 새 guard는 코드 경로를 확인했으며 별도 지연 로드 UI 재현은 실행하지 않았다. |
| F2 · 선수 교체 | `ObservePlayer`가 미완성 lap의 시간·trace·validity·sector를 초기화하고 기존 트랙 reference는 유지한다. Processor는 모든 packet header에서 선수 변경을 먼저 관측하여 telemetry/lap/header/CT2 cache를 비운다. | 기존에 실패한 독립 Go overlay가 PASS했다. 추가 production 회귀도 PASS하여 새 선수의 완전한 lap만 저장되고 모든 trace의 speed가 새 선수의 200인지 확인했다. 실제 Processor lap packet 검사에서 이전 telemetry/CT2 혼합 및 이전 선수 lap 완료가 차단됐다. |
| F3 · 저장 모드 | Sender callback이 mutex로 현재 설정을 읽고 `cfgSaveFiles && cfgDataStorageMode == advanced`일 때만 raw best-lap 저장소를 호출한다. 기존 server callback과 reference 읽기는 유지한다. | callback과 설정 변경 경로를 다시 대조했다. Result Only/Summary에서 새 raw best-lap 저장 경로가 닫혀 있다. Driver Pack 실행 후 실제 파일 생성까지의 통합 검증은 이 리뷰에서 수행하지 않았다. |
| F4 · 일반 Event 경계 | 공통 PM `ObserveSession(header)` 호출이 이전 세션 finalize 이후, packet별 PM feed 이전에 위치한다. 일반 SSTA/SEND도 동일한 UID/format/player 관측을 거친다. | 추가된 실제 Processor SSTA-first 회귀가 PASS했다. dashboard cache와 PM session/lap cache가 비워지고 PM UID가 10으로 갱신되는 assertion을 확인했다. |

실행한 독립 검사:

```text
node /tmp/frc-remediation-_xwlt3m5/followup-browser.mjs
→ pass: true (동일 UID/epoch 충돌 및 archive source 변경)

node /tmp/frc-remediation-_xwlt3m5/followup-views.mjs
→ production qualifying.browser.tsx 전체 PASS

go test -overlay=/tmp/frc-remediation-_xwlt3m5/delta_followup_overlay.json ./internal/telemetry -run 'TestReviewDeltaPlayerSwitchCannotCompletePreviousPlayerLap|TestDeltaPlayerSwitchCannotCompletePreviousPlayerLap|TestProcessorLoadsReferenceAndObservesLapPacketsBeforeRateLimit|TestDeltaAustraliaPersistenceValidityAndMinutes' -count=1
→ ok frc.engineer/internal/telemetry
```

`followup-browser.tsx`는 최종 production 공통 key를 사용하고 정상 불변식을 assert하도록 갱신했다. `followup-views.mjs`는 실제 제품의 추가 Chrome 회귀 suite만 실행하는 임시 runner다. 검사 후 자체 Chrome/Vite/profile을 모두 정리했고 제품 코드는 변경하지 않았다. 전체 의존성·CI·빌드 결과는 구현 담당자의 검증 범위다.
