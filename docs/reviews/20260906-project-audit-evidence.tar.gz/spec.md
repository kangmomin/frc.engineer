# Full project improvement audit
Goal: find remaining defects and concrete improvement opportunities across frc.engineer, prioritizing Pitwall and Sender.
Baseline: 84790bf5b7a8ae12c1706ed9a8d98ef9e79b70ef (v4.53.0).
Read-only review. Do not edit source or invoke external reviewer CLIs. Temporary repro artifacts only in this task directory; coordinate before cleanup. Preserve the five pre-existing untracked docs.

Plan and difficulty:
1. Map code, history, tests and accepted tradeoffs (low).
2. Root: Sender/Go validation, boundaries, auth, storage, concurrency, local HTTP and Electron, then broader backend audit (high).
3. Fresh independent reviewer: Pitwall/qualifying/frontend data semantics and intercom lifecycle correctness (high).
4. Cross-review every finding, reproduce concrete failures, separate verified defects from proposals or unverified risks (high).
5. Consolidate evidence, coverage and remaining verification gaps in a review artifact (medium).
No implementation or publishing in this audit. Do not claim exhaustive absence of bugs.

Already confirmed and not new:
- Session UID reset retains motion/telemetry/carDamage/carSetups.
- Restart merging tyre observed flags but dropping actual tyre values.
- 20 rejected uploads starve older pending uploads.
- v4.53 TryLock silently drops RPC/unicast replies (Pion repro vs v4.52).
- Restart overwrites previous Replay frames in same unsealed archive.
- ICE restart stays reconnecting if PC connected state never changes, then forces rejoin at 12 seconds (native Chrome repro).
- Client replay abort not propagated to Sender; cancelled transfer continues.
- Previously noted Electron/runtime dependency advisory and missing native Windows/browser CI/DB integration gates: reverify current state before reporting status.

Accepted limits (not new defects):
- Global upload seals across re-pair, boot/pair-only backlog sweep, 2h checkpoint hold.
- Final session-switch disk failure bounded retry.
- Windows replay snapshot copies local file under lock, temporary disk cost and forced-kill residue.

Independent reviewer deliverable:
Concrete findings with priority, trigger, observable harm, exact source lines, test/repro evidence and limits. Report rejected candidates and coverage briefly. Do not restate prior seven defects as discoveries. Prefer actual computations/browser tests over style opinions. Root will independently review.

