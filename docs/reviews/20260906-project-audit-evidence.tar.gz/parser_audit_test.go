package udp

import (
	"encoding/binary"
	"io"
	"log/slog"
	"math/rand"
	"testing"
)

func TestAuditParserRandomWireInputs(t *testing.T) {
	p := NewParser(slog.New(slog.NewTextHandler(io.Discard, nil)))
	rng := rand.New(rand.NewSource(453))
	parsedCount := 0
	for i := 0; i < 25000; i++ {
		size := rng.Intn(4097)
		data := make([]byte, size)
		_, _ = rng.Read(data)
		if size >= 29 {
			binary.LittleEndian.PutUint16(data, uint16(2024+i%3))
			data[6] = byte(i%17)
		}
		func() {
			defer func() {
				if value := recover(); value != nil { t.Fatalf("panic case=%d bytes=%d: %v", i, size, value) }
			}()
			parsed, err := p.Parse(data)
			if err == nil && parsed != nil { parsedCount++ }
		}()
	}
	t.Logf("25000 deterministic payloads, lengths 0..4096, formats 2024/2025/2026, packet IDs 0..16: %d parsed, no panic; processor not invoked", parsedCount)
}
