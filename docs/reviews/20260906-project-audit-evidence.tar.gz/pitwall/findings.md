# Independent Pitwall / qualifying / intercom audit

Baseline: `84790bf5b7a8ae12c1706ed9a8d98ef9e79b70ef` (v4.53.0). Read-only; no tracked source changes. The seven already-known findings in the audit spec are excluded.

## Reproduction and scope

Run `node /tmp/frc-full-audit-a11yogpw/pitwall/run-browser.mjs` from any directory. It bundles the actual checked-out TypeScript with existing esbuild, starts an isolated local server and native headless Chrome, runs actual React hooks, Zustand trackers, pure derivations and intercom runtime, writes `repro-results.json`, and closes Chrome/server/removes the temporary Chrome profile. Last successful run: exit 0, approximately 1.3 seconds.

Intercom group signaling is controlled by the harness. Its media uses native Chrome `RTCPeerConnection` peers, an oscillator-created `MediaStreamTrack`, a receiving audio element, and native `getStats()`. Autoplay is permitted for this isolated audio test. No production signaling/SFU service is contacted.

Producer DTO cross-check: `go test -overlay /tmp/frc-full-audit-a11yogpw/pitwall/go-overlay.json ./internal/telemetry -run '^TestAuditInvalidQualifyingLapDTO$' -v` passed. The overlay adds only a virtual test file; the repository stays unchanged.

## IC-1 — P1: Leave can reopen the microphone before its acknowledgement

Primary location: `web/src/intercom/core/runtime.ts:171-182`. Gate reentry: `runtime.ts:422-424, 514-536`; physical peer close: `web/src/intercom/core/sfu.ts:350-358`.

`leave()` calls `failClosed()` but retains membership, status `joined`, and media status `connected` while awaiting the leave RPC (up to 4 seconds). A normal higher-revision `intercom_state` still passes `onMessage` and calls `applyGates()`, reopening an enabled engineer bus or driver microphone. The audio peer is not closed until after the acknowledgement. An already-in-flight activity snapshot can therefore resume transmission after the user clicks Leave, while the server still has the member.

Native reproduction: before Leave, an engineer bus publication is connected. Immediately after Leave, `track.enabled=false`, status is still `joined`. Deliver revision 2 before the leave ACK: `track.enabled=true`, native sending PC remains `connected`, and receiving `totalAudioEnergy` rises by `0.14687374116911348` over the following 250 ms. Only then send the ACK and observe teardown. This proves actual audio transfer, not only an enabled flag.

Suggested correction: establish a synchronous local leaving/closed generation before waiting for server acknowledgement; invalidate pending microphone/media work and ensure every source/sink gate respects it. Stop the local media immediately, with the server leave performed as cleanup. Validate a delayed ACK with an intervening snapshot and pending getUserMedia.

Limit: controlled group-signaling sequence and native local media pair; no live Cloudflare SFU call. The reopening path applies identically to the established publication objects used by the SFU controller.

## PW-1 — P2: Replay uses lap history from the live race

Primary location: `web/src/views/pitwall/PitWallView.tsx:63,98` and `web/src/views/pitwall/derive/leaderboardRows.ts:430-432`. The live-only tracker intentionally skips replay frames at `web/src/store/lapHistoryStore.ts:244-246`. `QualifyingView.tsx:81-85` has the same unconditional history consumption. `RaceArchiveDrawer.tsx:294-298` replaces telemetry with replay state while its HUD overlays the existing view.

Replay drivers and session come from the selected archive, while the latest lap records still come from the live store, keyed only by car index. Reproduction first records a live Australian lap 10 with sectors 30/31/32 seconds, then opens a British replay at lap 4 with a different named driver at index 0 and a last lap of 110 seconds. The row displays replay last lap `1:50.000`, but sectors `30.000 / 31.000 / 32.000` from the 93-second live lap. Driver detail tables/charts consume the same live history. World grid movement also reads frozen live race metadata, although only sector contamination was dynamically reproduced.

Suggested correction: provide isolated replay metadata/history derived from the archive through the selected frame (including seek/rewind), or explicitly suppress unavailable derived data during replay. Preserve the existing separation that prevents replay frames from mutating live history.

## PW-2 — P2: A driver in the drop zone receives the wrong improvement target

Primary location: `web/src/views/qualifying/derive/cutoffWatch.ts:94-104`.

The cutoff driver is always `sorted[safeCount]`, the first eliminated driver. This is a useful threat reference for a currently safe driver, but an eliminated driver needs to beat the last advancing driver, `sorted[safeCount-1]`. In a 20-car Q1 with P15 at 91.400 seconds and P16 at 91.500 seconds, P16 is told `Need 0.000s` because it is compared with itself; reaching P15 actually requires more than 0.100 seconds improvement. Drivers further back are also shown a systematically understated target.

Reproduced in Chrome with actual `deriveCutoffWatch`; `repro-results.json.cutoffMargin`. Existing test `cutoffWatch.test.ts` deliberately allows `Need 0.000s`; this is a domain expectation encoded incorrectly in the test, not evidence of correct qualification advice. No history/user decision was found authorizing this misleading target.

Suggested correction: choose the reference based on whether the player is safe or eliminated, keeping target position/code/margin consistent. A tie also needs the game’s chronological tie-break rule or appropriately conservative wording.

## PW-3 — P2: Invalid last laps can become POLE when no valid best exists

Primary location: `web/src/components/qualifying/leaderboardOrder.ts:3-10`; displayed best/POLE: `web/src/views/qualifying/derive/classificationRows.ts:144-145,169`.

The fallback from `bestLapTime` to any positive `lastLapTime` conflates unavailable session-history data with the authoritative absence of a valid lap. After an invalid lap crosses the line, `lapInvalid` describes the new lap and is false; the old invalid lap remains in `lastLapTime`, while session history correctly leaves `BestLapTimeLapNum=0`. The browser promotes that invalid last lap to best and sorts it into classification.

Canonical producer test supplies a 77-second invalid completed lap and valid 82-second rival. `PitwallManager` outputs `{position:20,bestLapTime:0,lastLapTime:77000,lapInvalid:false}` and `{position:1,bestLapTime:82000,lastLapTime:82000,lapInvalid:false}`. Browser derivation moves the first driver to `01`, shows `1:17.000` and `POLE`. The exact fixture is reachable through the actual Go producer, not merely malformed JavaScript input.

History intent checked: commit `18a86dd2` introduced last-lap fallback to avoid an empty best display while session history was missing. That intent does not authorize treating known invalid laps as qualifying results.

Suggested correction: expose last-lap validity/history availability or maintain a valid-lap cache, and only use a confirmed valid temporary best. Current-lap `lapInvalid` alone cannot establish previous-lap validity.

## PW-4 — P2: Best-sector displays ignore authoritative history and accept invalid sectors

Primary location: `web/src/views/qualifying/useSectorAccumulator.ts:75-95`; consumer: `web/src/views/qualifying/derive/classificationRows.ts:149-151`. Authoritative producer: `internal/telemetry/pitwall_manager.go:871-893`.

The displayed best sectors are exclusively view-local minima of live S1/S2 and reconstructed S3. Incoming `bestSector1Ms/2Ms/3Ms` are not used to initialize or correct these display values, although `buildTryBaseline()` already prefers them for another calculation.

Native React reproduction on mounting with all three authoritative bests at 30 seconds yields accumulated `0/0/0` and empty sector displays; navigating away and back loses the previous observations. A later invalid lap with S1=20 seconds and official valid best still 30 seconds permanently replaces the accumulator with 20 seconds and paints it purple. Subsequent valid laps are compared against a cut lap. The accumulator also lacks per-sector validity and cannot roll back previously observed invalidated sectors.

Suggested correction: use session-history bests as the display source and purple reference, with explicitly provisional, validity-aware live fallback only while those fields are unavailable. Keep accumulators outside a conditionally mounted view if historical observation remains necessary.

## PW-5 — P2: Qualifying phase state crosses segment/player boundaries

Primary location: `web/src/hooks/useQualifyingState.ts:190-213`; rewind check: `:88-90`; caller: `web/src/views/qualifying/QualifyingView.tsx:62-64`.

The hook has no session, epoch, or driver-identity key; it resets only when qualification/player presence becomes false, or when lap number rewinds by more than one. Consecutive qualifying segments remain `isQualifying=true`. If the observed lap changes 2→1 or the same lap number appears for a new selected car/session, the previous phase, attempts, and best reference persist.

Native React sequence: observe Q1 pit exit at lap 1 and entry into flying lap 2, then Q2 starts at lap 1 in garage. State remains `FLYING`, attempt 1, consecutive push laps 1, instead of a reset/new segment state. The separate sector accumulator receives `epoch`, but this hook does not.

Suggested correction: pass a stable session/segment and player key into the state machine, reset previous-frame and reducer state together at that boundary. Do not rely on lap-number magnitude as a substitute for identity.

Limit: the exact boundary sequence is simulated; normal transitions that happen to provide a >1 lap rewind or an empty driver frame already reset and do not trigger this defect.

## PW-6 — P2: 20-car knockout constants misclassify standard 2026 Q1

Primary location: `web/src/views/qualifying/derive/qualiSegment.ts:21-25,38-41`; related Q2 active-group threshold: `web/src/components/qualifying/leaderboardOrder.ts:30-37`. `QualifyingView.tsx:76` passes only session type, so neither game format nor actual eligible grid can change the constants.

A standard 22-car 2026 Q1 advances 16 cars, but the UI always declares only 15 safe and says `P16–20 out`. Reproduction with 22 drivers marks P16 `IN THE DROP ZONE`. Q2 labels omit P16 and its knockout-group helper also assumes only 15 active cars. This is separate from PW-2: the qualification threshold is wrong even before calculating its margin.

Authoritative validation: [FIA 2026 sporting regulations, issue 06](https://api.fia.com/system/files/documents/fia_2026_f1_regulations_-_section_b_sporting_-_iss_06_-_2026-04-28.pdf), B2.4.2 (PDF page 21) specifies 16 drivers in Q2; B2.4.3 (page 23) scales elimination to 5 for 20 cars and 7 for 24 cars. B2.2.2/B2.2.3 give the same scaling for sprint qualifying. [EA’s F1 25 Features](https://www.ea.com/games/f1/f1-25/features) identifies the 2026 Season Pack as the official 2026 game and Cadillac’s addition. Do not infer eligible cars or a cutoff solely from UDP MaxCars=24: that is packet capacity, and custom formats/series require explicit metadata or safe degradation.

Limit: current FIA rules and source behavior are verified, but no full 2026 in-game Q1→Q2 capture was present in this checkout. This is a standard-format compatibility defect; custom lobby/F2 behavior needs captured evidence before choosing the final implementation policy.

## PW-7 — P2: Frontend cannot identify a same-format session restart without a lap rewind

Primary location: `web/src/store/raceMetaStore.ts:37-38,75-82`. The wire DTO lacks session UID: `internal/dto/pitwall.go:4-13,75-89`. Consumers include the modal close gate at `web/src/views/pitwall/PitWallView.tsx:79-82`, lap history generation and qualifying accumulators.

Frontend identity is only track/type/total laps plus a positive maximum-lap decrease. Restarting on lap 1, or reconnecting into a different same-format session at the same observed lap, does not change this key. Even if the sender correctly clears all its state for the new UID, old frontend grid/history/selected-car state can survive.

Actual tracker reproduction captures grid `{0:1,1:2}` at lap 1, then feeds the first lap of a same-track/type/distance session with grid `{0:2,1:1}`. Epoch remains 5 and the old grid remains captured. Slot reuse can leave the detail modal pointing at another participant. With no UID or equivalent generation on the wire, the browser cannot reliably distinguish these from ordinary lap-1 position changes.

Suggested correction: include an authoritative session identity/generation in the Pitwall DTO and consistently reset session-derived stores on it. Preserve transient reconnects within the same session. This is distinct from the known backend cache-retention defect: fully correct new raw data still cannot reset this client state.

## Coverage, rejected candidates and limits

Read PitWallView, leaderboard/sector/my-car/pit-exit/tyre/weather/detail derivations, qualifying classification/cutoff/phase/accumulator/threat derivations, track gaps, strategy RPC lifecycle, telemetry/race-meta/lap-history stores, replay HUD/application path, shared intercom runtime/SFU/source/sink gates and both surface hooks. Cross-read producer DTO/session-history paths and relevant tests/history. The comparison chart and display-preference code received a source pass, not exhaustive UI interaction coverage.

Excluded: full measured pit-lane duration versus net pit-loss bias, explicitly accepted by the user in `history/20260720-pitwall-pit-loss-measured-and-server-avg.md`; independent local pit-loss settings and deferred server-average consumption are also documented decisions. Missing/non-finite telemetry defensive styling was not promoted without a realistic producer path. Same-millisecond repeated-lap omission is conservatively documented around garage teleport detection, so it was not promoted as a new finding. No broad baseline tests were repeated.

Root findings independently cross-checked: local analysis hardcodes all completed laps valid; reads sectors from rollover/reset frame and omits minute parts; tyre merge compares tyre age to absolute race lap and ignores timestamp; session list sorts UID-prefixed directory names. Root’s replay copier also omits SessionTimeLeft/SessionDuration: qualifying replay header renders `--:--` (`QualifyingHeader.tsx:25-29`) and CutoffWatch gives an under-90-second warning for every zero-time replay frame (`cutoffWatch.ts:36-39`). These remain owned by root rather than duplicated in the numbered findings above.

All temporary artifacts stay under this audit’s `pitwall/` directory for root to consolidate, then clean. The native Chrome profile and server are already stopped/removed. The repository still has only its five pre-existing untracked docs.
