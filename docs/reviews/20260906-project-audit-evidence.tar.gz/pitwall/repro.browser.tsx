import React, { useEffect } from '/workspace/frc.engineer/web/node_modules/react/index.js';
import { createRoot } from '/workspace/frc.engineer/web/node_modules/react-dom/client.js';
import { deriveQualiSegment } from '/workspace/frc.engineer/web/src/views/qualifying/derive/qualiSegment';
import { deriveCutoffWatch } from '/workspace/frc.engineer/web/src/views/qualifying/derive/cutoffWatch';
import { sortQualifyingDrivers } from '/workspace/frc.engineer/web/src/components/qualifying/leaderboardOrder';
import { useSectorAccumulator, computeOverallBestSectors } from '/workspace/frc.engineer/web/src/views/qualifying/useSectorAccumulator';
import { deriveClassificationRows } from '/workspace/frc.engineer/web/src/views/qualifying/derive/classificationRows';
import { useQualifyingState } from '/workspace/frc.engineer/web/src/hooks/useQualifyingState';
import { useTelemetryStore } from '/workspace/frc.engineer/web/src/store/telemetryStore';
import { startLapHistoryTracker, useLapHistoryStore } from '/workspace/frc.engineer/web/src/store/lapHistoryStore';
import { startRaceMetaTracker, useRaceMetaStore } from '/workspace/frc.engineer/web/src/store/raceMetaStore';
import { deriveLeaderboardRows } from '/workspace/frc.engineer/web/src/views/pitwall/derive/leaderboardRows';
import { IntercomRuntime } from '/workspace/frc.engineer/web/src/intercom/core/runtime';
import { waitForIceGatheringComplete } from '/workspace/frc.engineer/web/src/intercom/core/sfu';

const results: Record<string, unknown> = {};
const wait = (ms = 20) => new Promise((resolve) => setTimeout(resolve, ms));
const check = (value: unknown, message: string) => { if (!value) throw Error(message); };
function driver(overrides: Record<string, unknown> = {}) {
  return { index: 0, name: 'Live Driver', teamId: 0, aiControlled: false, position: 1,
    currentLapNum: 2, speed: 230, topSpeed: 310, throttle: 1, brake: 0, gear: 6, steering: 0,
    drsActivated: false, lastLapTime: 0, bestLapTime: 0, tireCompound: 'soft', tireAge: 2,
    tireWear: [10,10,10,10], tireSurfaceTemp: [90,90,90,90], tireInnerTemp: [90,90,90,90],
    brakeTemp: [500,500,500,500], brakeBias: 55, diffOnThrottle: 50, diffOffThrottle: 50,
    fuelInTank: 20, fuelRemainingLaps: 2, fuelMix: 2, ersStoreEnergy: 2000000,
    ersDeployMode: 2, ersDeployedThisLap: 0, ersHarvestedThisLap: 0,
    ersEstimatePct: 80, ersEstimateReady: true, ersActualPct: 80, ersActualReady: true,
    sector1TimeMs: 0, sector2TimeMs: 0, currentSector: 0, penalties: 0, totalWarnings: 0,
    cornerCuttingWarnings: 0, numUnservedDriveThroughs: 0, numUnservedStopGoPenalties: 0,
    lapInvalid: false, pitStatus: 0, driverStatus: 1, resultStatus: 2, numPitStops: 0,
    lapDistance: 500, pitStopTimer: 0, ...overrides } as any;
}
const session = { trackId: 0, trackName: 'Australia', sessionType: 'Race', totalLaps: 29, trackLength: 5300,
  weather: 'clear', safetyCar: 'none', trackTemp: 30, airTemp: 25 } as any;
const pitwall = (d: any, s: any = session) => ({ session: s, drivers: [d], playerIndex: d.index, positions: [], gameFormat: 2025 } as any);

function pureCases() {
  const field = Array.from({length: 20}, (_, i) => driver({index: i, position: i+1, bestLapTime: 90000 + i * 100}));
  const vm = deriveCutoffWatch(field[15], field, deriveQualiSegment('Q1'), 100, new Map());
  check(vm.marginText === 'Need 0.000s', 'cutoff fixture drifted');
  results.cutoffMargin = { current: vm.marginText, requiredToReachP15Ms: field[15].bestLapTime - field[14].bestLapTime,
    targetShown: vm.cutoffPosText };
  const field22 = Array.from({length:22},(_,i) => driver({index:i,position:i+1,bestLapTime:90000+i*100}));
  results.standard2026Q1 = { grid:22, gameFormat:2026, publishedFIAAdvancingCars:16,
    configuredAdvancingCars:deriveQualiSegment('Q1').safeCount,
    P16Status:deriveCutoffWatch(field22[15],field22,deriveQualiSegment('Q1'),100,new Map()).statusLabel };

  const invalid = driver({index: 16, position: 20, bestLapTime: 0, lastLapTime: 77000, lapInvalid: false});
  const valid = driver({index: 0, position: 1, bestLapTime: 82000, lastLapTime: 82000});
  const sorted = sortQualifyingDrivers([valid, invalid], 'Q1');
  const rows = deriveClassificationRows(sorted, new Map(), new Map(), {bestS1:0,bestS2:0,bestS3:0},
    deriveQualiSegment('Q1'), invalid, 77000, new Map());
  check(rows[0].index === 16 && rows[0].gap === 'POLE', 'invalid lap fixture drifted');
  results.invalidLastLap = { officialNoTimeDriverPosition: invalid.position, displayedRank: rows[0].pos,
    displayedBest: rows[0].best, gapLabel: rows[0].gap };
}

async function sectorCases() {
  const node = document.createElement('div'); document.body.append(node);
  const root = createRoot(node);
  let observed: any;
  const qSession = {...session, sessionType:'Q1'};
  function Probe({d}: {d: any}) {
    const acc = useSectorAccumulator([d], qSession, 1);
    useEffect(() => { observed = acc.get(0); }, [acc]);
    return null;
  }
  // Memoize driver-array via a stable wrapper to avoid artificial render churn.
  function StableProbe({drivers}: {drivers: any[]}) {
    const acc = useSectorAccumulator(drivers, qSession, 1);
    useEffect(() => { observed = acc.get(0); }, [acc]);
    return null;
  }
  const fresh = driver({ bestSector1Ms: 30000, bestSector2Ms: 30000, bestSector3Ms: 30000, bestLapTime: 90000 });
  root.render(<StableProbe drivers={[fresh]} />);
  await wait(60);
  check(observed?.bestS1 === 0, 'sector late-join fixture drifted');
  results.sectorLateJoin = { authoritativeBest: [fresh.bestSector1Ms, fresh.bestSector2Ms, fresh.bestSector3Ms], shownAccumulated: {...observed} };
  const cut = driver({...fresh, currentSector: 2, sector1TimeMs: 20000, sector2TimeMs: 25000, lapInvalid: true});
  root.render(<StableProbe drivers={[cut]} />); await wait();
  const accumulated = {...observed};
  check(accumulated.bestS1 === 20000, 'invalid sector fixture drifted');
  const rows = deriveClassificationRows([cut], new Map([[0,accumulated]]), new Map(),
    computeOverallBestSectors(new Map([[0,accumulated]])), deriveQualiSegment('Q1'), cut, 90000, new Map());
  results.invalidSector = { authoritativeBest: cut.bestSector1Ms, lapInvalid: cut.lapInvalid,
    displayedSector: rows[0].s1, displayedColor: rows[0].s1Color };
  root.unmount(); node.remove();
}

async function qualifyingIdentityCase() {
  const node = document.createElement('div'); document.body.append(node);
  const root = createRoot(node);
  let observed: any;
  function Probe({d, segment}: {d:any, segment:string}) {
    const state = useQualifyingState(d, d.lapInvalid, segment.startsWith('Q'));
    useEffect(() => { observed = state; }, [state]);
    return null;
  }
  // End a first attempt in Q1, then Q2 begins without a >1 lap rewind.
  root.render(<Probe d={driver({currentLapNum:1,pitStatus:1})} segment="Q1" />); await wait();
  root.render(<Probe d={driver({currentLapNum:1,pitStatus:0})} segment="Q1" />); await wait();
  root.render(<Probe d={driver({currentLapNum:2,pitStatus:0})} segment="Q1" />); await wait();
  check(observed.phase === 'FLYING', 'qualifying phase setup failed');
  const before = {...observed};
  root.render(<Probe d={driver({currentLapNum:1,pitStatus:0,driverStatus:0,bestLapTime:0,lastLapTime:0})} segment="Q2" />); await wait();
  results.qualifyingSegmentReset = { Q1: before, Q2Garage: {...observed} };
  check(observed.phase === 'FLYING' && observed.attemptNumber === 1, 'Q2 reset fixture drifted');
  root.unmount(); node.remove();
}

function replayHistoryCase() {
  startRaceMetaTracker(); startLapHistoryTracker();
  const t = useTelemetryStore.getState(); t.resetRoom();
  t.setPitwallState(pitwall(driver({currentLapNum:10,currentSector:2,sector1TimeMs:30000,sector2TimeMs:31000,lastLapTime:99000})));
  t.setPitwallState(pitwall(driver({currentLapNum:11,currentSector:0,lastLapTime:93000})));
  const history = useLapHistoryStore.getState().history;
  check(history.get(0)?.[0]?.s3Ms === 32000, 'live history fixture failed');
  const oldDriver = driver({name:'Archived Driver',currentLapNum:4,currentSector:0,lastLapTime:110000});
  t.setPlaybackActive(true);
  t.applyReplayFrame({pitwall:pitwall(oldDriver,{...session,trackId:9,trackName:'Great Britain'})});
  const state = useTelemetryStore.getState().pitwallState!;
  const row = deriveLeaderboardRows(state.drivers,state.drivers[0],false,state.session,useLapHistoryStore.getState().history)[0];
  results.replayHistory = { replayTrack:state.session.trackName, replayDriver:row.name, replayLastLap:row.lastLap,
    displayedSectors:[row.s1,row.s2,row.s3], displayedSectorsSumMs:30000+31000+32000,
    sourceHistoryLap:useLapHistoryStore.getState().history.get(0)?.[0]?.lap,
    unchangedLiveHistory:useLapHistoryStore.getState().history === history };
  check(row.s3 === '32.000', 'replay leakage fixture drifted');
  t.setPlaybackActive(false); t.resetRoom();
}

function sameFormatRestartCase() {
  const t=useTelemetryStore.getState();t.resetRoom();
  const a=driver({index:0,position:1,currentLapNum:1}),b=driver({index:1,position:2,currentLapNum:1});
  t.setPitwallState({...pitwall(a),drivers:[a,b]});
  const before={epoch:useRaceMetaStore.getState().epoch,grid:{...useRaceMetaStore.getState().grid}};
  // The new session UID is unavailable on the wire. First-lap restart, same track/type/distance.
  const a2={...a,position:2},b2={...b,position:1};
  t.setPitwallState({...pitwall(a2),drivers:[a2,b2]});
  const after={epoch:useRaceMetaStore.getState().epoch,grid:{...useRaceMetaStore.getState().grid}};
  results.sameFormatRestart={before,after,actualNewGrid:{0:2,1:1}};
  check(before.epoch===after.epoch && after.grid[0]===1,'first-lap restart fixture drifted');
  t.resetRoom();
}

async function leaveMicrophoneCase() {
  const runtime = new IntercomRuntime();
  const inner = runtime as any;
  const listeners = new Set<(message:any)=>void>();
  let leaveRequestId = '';
  const snapshot = {revision:1,topologyRevision:1,groupCode:'123456',participants:[
    {id:'engineer-a',role:'engineer',displayName:'Engineer',online:true,speaking:false,ptt:false,
      busEnabled:true,forcedMuted:false,talkingTo:[],assignmentDriverKey:'driver-a'}]};
  runtime.setTransport({generation:1,joined:true,intercomVersion:1,
    sendIntercom(message:any) {
      if (message.type === 'intercom_join') queueMicrotask(() => {
        for (const listener of listeners) listener({type:'intercom_joined',requestId:message.requestId,payload:{
          groupCode:'123456',participantId:'engineer-a',membershipGeneration:1,resumeToken:'resume-token',
          sfuEnabled:false,snapshot }});
      });
      if (message.type === 'intercom_leave') leaveRequestId = message.requestId;
      return true;
    },subscribeIntercom(listener:any) {listeners.add(listener); return () => listeners.delete(listener);} });
  await runtime.join({groupCode:'123456',password:'test-only',role:'engineer',displayName:'Engineer'});
  check(runtime.getState().status === 'joined', 'intercom join fixture failed');
  // Model an established SFU publication using an actual local WebRTC audio pair.
  // Group signaling is controlled; the peer, audio encoding, and receiving stats are native Chrome.
  const context = new AudioContext();
  await context.resume();
  const destination = context.createMediaStreamDestination();
  const oscillator = context.createOscillator(); oscillator.connect(destination); oscillator.start();
  const track = destination.stream.getAudioTracks()[0];
  const sendingPC = new RTCPeerConnection({iceServers:[]});
  const receivingPC = new RTCPeerConnection({iceServers:[]});
  const playbackElement=document.createElement('audio');document.body.append(playbackElement);playbackElement.autoplay=true;
  receivingPC.ontrack=(event)=>{
    playbackElement.srcObject=new MediaStream([event.track]);void playbackElement.play();
    const source=context.createMediaStreamSource(new MediaStream([event.track]));
    const sink=context.createGain();sink.gain.value=0;source.connect(sink);sink.connect(context.destination);
  };
  const transceiver = sendingPC.addTransceiver(track,{direction:'sendonly'});
  await sendingPC.setLocalDescription(await sendingPC.createOffer());
  await waitForIceGatheringComplete(sendingPC);
  await receivingPC.setRemoteDescription(sendingPC.localDescription!);
  await receivingPC.setLocalDescription(await receivingPC.createAnswer());
  await waitForIceGatheringComplete(receivingPC);
  await sendingPC.setRemoteDescription(receivingPC.localDescription!);
  const deadline=Date.now()+4000;
  while(sendingPC.connectionState!=='connected') {check(Date.now()<deadline,'native audio pair failed');await wait();}
  inner.audio.pc=sendingPC;
  inner.audio.publications = [{key:'engineer_bus',clone:track,sender:transceiver.sender,transceiver}];
  inner.state = {...inner.state,mediaStatus:'connected',microphoneStatus:'live'};
  runtime.setBusEnabled(true);
  check(track.enabled, 'intercom publication fixture failed');
  await wait(150);
  const leaving = runtime.leave();
  check(!track.enabled && leaveRequestId, 'leave did not immediately close publication');
  const immediatelyAfterClick = { trackEnabled:track.enabled,status:runtime.getState().status };
  await wait(150);
  const energy=async()=>{let result=0;for(const stat of (await receivingPC.getStats()).values())if(stat.type==='inbound-rtp'&&stat.kind==='audio')result=stat.totalAudioEnergy??0;return result;};
  const beforeEnergy=await energy();
  // A previously sent activity snapshot can arrive while the leave ACK is in flight.
  for (const listener of listeners) listener({type:'intercom_state',payload:{...snapshot,revision:2}});
  const beforeAck = { trackEnabled:track.enabled,status:runtime.getState().status };
  check(track.enabled, 'leave source reopening fixture drifted');
  await wait(250);
  const afterEnergy=await energy();
  results.intercomLeave = { immediatelyAfterClick, afterSnapshotBeforeLeaveAck:beforeAck,
    nativePeerBeforeAck:sendingPC.connectionState, receivedEnergyIncrease:afterEnergy-beforeEnergy };
  check(sendingPC.connectionState==='connected' && afterEnergy>beforeEnergy,`no native audio received after source reopened ${JSON.stringify({beforeEnergy,afterEnergy,context:context.state,stats:[...(await receivingPC.getStats()).values()].filter(s=>s.type==='inbound-rtp')})}`);
  for (const listener of listeners) listener({type:'intercom_left',requestId:leaveRequestId,payload:{}});
  await leaving;
  runtime.close(); track.stop(); receivingPC.close(); oscillator.stop();playbackElement.remove();await context.close();
}

export async function run() {
  pureCases();
  await sectorCases();
  await qualifyingIdentityCase();
  replayHistoryCase();
  sameFormatRestartCase();
  await leaveMicrophoneCase();
  return results;
}
