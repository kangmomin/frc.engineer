package telemetry

import (
    "encoding/json"
    "testing"

    "frc.engineer/internal/packets"
)

func TestAuditInvalidQualifyingLapDTO(t *testing.T) {
    header := packets.PacketHeader{SessionUID: 123, PacketFormat: 2026, PlayerCarIndex: 0}
    pm := NewPitwallManager(NewStrategyManager(), nil, nil)
    pm.UpdateSession(&packets.PacketSessionData{Header: header, SessionType: 5})
    pm.UpdateParticipants(&packets.PacketParticipantsData{Header: header, NumActiveCars: 2})
    ld := &packets.PacketLapData{Header: header}
    ld.LapData[0] = packets.LapData{CurrentLapNum: 3, LastLapTimeInMS: 77000, CarPosition: 20, CurrentLapInvalid: 0}
    ld.LapData[1] = packets.LapData{CurrentLapNum: 3, LastLapTimeInMS: 82000, CarPosition: 1, CurrentLapInvalid: 0}
    pm.UpdateLapData(ld)
    invalidHistory := &packets.PacketSessionHistoryData{Header: header, CarIdx: 0, NumLaps: 2, BestLapTimeLapNum: 0}
    invalidHistory.LapHistoryData[1] = packets.LapHistoryData{LapTimeInMS: 77000, LapValidBitFlags: 0}
    pm.UpdateSessionHistory(invalidHistory)
    validHistory := &packets.PacketSessionHistoryData{Header: header, CarIdx: 1, NumLaps: 2, BestLapTimeLapNum: 2}
    validHistory.LapHistoryData[1] = packets.LapHistoryData{LapTimeInMS: 82000, LapValidBitFlags: 15}
    pm.UpdateSessionHistory(validHistory)
    state := pm.BuildState()
    a, b := state.Drivers[0], state.Drivers[1]
    raw, err := json.Marshal([]any{
        map[string]any{"index": a.Index, "position": a.Position, "bestLapTime": a.BestLapTime, "lastLapTime": a.LastLapTime, "lapInvalid": a.LapInvalid},
        map[string]any{"index": b.Index, "position": b.Position, "bestLapTime": b.BestLapTime, "lastLapTime": b.LastLapTime, "lapInvalid": b.LapInvalid},
    })
    if err != nil { t.Fatal(err) }
    t.Logf("canonical DTO %s", raw)
    if a.BestLapTime != 0 || a.LastLapTime != 77000 || a.LapInvalid || b.BestLapTime != 82000 {
        t.Fatal("browser fixture no longer corresponds to canonical producer DTO")
    }
}
