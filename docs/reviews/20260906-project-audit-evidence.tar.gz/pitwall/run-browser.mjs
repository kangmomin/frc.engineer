import { build } from '/workspace/frc.engineer/web/node_modules/esbuild/lib/main.js';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdtemp, rm } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
const dir = '/tmp/frc-full-audit-a11yogpw/pitwall';
await build({entryPoints:[`${dir}/repro.browser.tsx`],bundle:true,format:'esm',platform:'browser',outfile:`${dir}/repro.bundle.js`,jsx:'automatic',jsxImportSource:'/workspace/frc.engineer/web/node_modules/react'});
const profile = await mkdtemp(`${dir}/chrome-`);
const server = createServer(async (req,res) => {
  res.setHeader('Content-Type',req.url === '/repro.js' ? 'text/javascript':'text/html');
  res.end(req.url === '/repro.js' ? await readFile(`${dir}/repro.bundle.js`):'<!doctype html><body></body>');
});
await new Promise(resolve => server.listen(0,'127.0.0.1',resolve));
let chrome, socket, deadline;
try {
  await Promise.race([(async () => {
    const endpoint = await new Promise((resolve,reject) => {
      chrome = spawn('google-chrome',['--headless=new','--no-sandbox','--disable-gpu','--autoplay-policy=no-user-gesture-required','--remote-debugging-port=0',`--user-data-dir=${profile}`,'about:blank'],{stdio:['ignore','ignore','pipe']});
      chrome.once('error',reject);
      let output=''; chrome.stderr.on('data',chunk => {
        output += chunk; const endpoint=output.match(/DevTools listening on (ws:\/\/[^\s]+)/)?.[1]; if(endpoint) resolve(endpoint);
      });
    });
    const url = new URL(endpoint);
    const target = await fetch(`http://${url.host}/json/new?about:blank`,{method:'PUT'}).then(r=>r.json());
    socket = new WebSocket(target.webSocketDebuggerUrl);
    await new Promise((resolve,reject) => {socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
    let seq=0; const pending=new Map();
    socket.addEventListener('message',({data}) => { const m=JSON.parse(data),p=pending.get(m.id); if(!p)return; pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result); });
    const call=(method,params={})=>new Promise((resolve,reject)=>{const id=++seq;pending.set(id,{resolve,reject});socket.send(JSON.stringify({id,method,params}));});
    await call('Page.enable');
    const loaded=new Promise(resolve=>socket.addEventListener('message',function listener({data}){if(JSON.parse(data).method!=='Page.loadEventFired')return;socket.removeEventListener('message',listener);resolve();}));
    await call('Page.navigate',{url:`http://127.0.0.1:${server.address().port}/`});await loaded;
    const result=await call('Runtime.evaluate',{expression:'import("/repro.js").then(m=>m.run())',awaitPromise:true,returnByValue:true,userGesture:true});
    if(result.exceptionDetails)throw Error(result.exceptionDetails.exception?.description||result.exceptionDetails.text);
    await writeFile(`${dir}/repro-results.json`,JSON.stringify(result.result.value,null,2));
    console.log(JSON.stringify(result.result.value,null,2));
  })(),new Promise((_,reject)=>{deadline=setTimeout(()=>reject(Error('audit browser timeout')),30000);})]);
} finally {
  clearTimeout(deadline);socket?.close();
  if(chrome && chrome.exitCode===null){const done=once(chrome,'exit');chrome.kill('SIGTERM');await done;}
  await new Promise(resolve=>server.close(resolve));
  await rm(profile,{recursive:true,force:true,maxRetries:5,retryDelay:100});
}
