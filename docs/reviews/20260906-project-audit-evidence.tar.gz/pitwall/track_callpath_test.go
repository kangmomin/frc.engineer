package telemetry

import (
    "bytes"
    "io"
    "log/slog"
    "os"
    "path/filepath"
    "testing"

    "frc.engineer/internal/packets"
    "frc.engineer/internal/tracks"
)

func TestAuditTrackBoundaryViaPitwallManager(t *testing.T) {
    logger := slog.New(slog.NewTextHandler(io.Discard, nil))
    oldLogger := slog.Default()
    slog.SetDefault(logger)
    t.Cleanup(func(){slog.SetDefault(oldLogger)})
    for _, test := range []struct{name string; nextUID uint64; nextTrack int8; nextDist float32}{
        {"flashback_same_uid", 1, 0, 3000},
        {"session_change_new_uid_and_track", 2, 3, 2},
    } {
        t.Run(test.name, func(t *testing.T){
            dir := t.TempDir()
            store := tracks.NewTrackStore(dir)
            recorder := NewTrackRecorder(dir, store, logger)
            initial := make([]recordPoint, 501)
            for i := range initial {initial[i]=recordPoint{Dist:2+float32(i)*10,X:float32(i),Z:float32(i%20)}}
            recorder.saveLap(0,"Australia",initial)
            path:=filepath.Join(dir,tracks.TrackStorageKey(0)+"_recorded.txt")
            before,err:=os.ReadFile(path);if err!=nil{t.Fatal(err)}
            recorder.SetEnabled(true)
            manager:=NewPitwallManager(NewStrategyManager(),store,recorder)
            header:=packets.PacketHeader{SessionUID:1,PacketFormat:2026,PlayerCarIndex:0}
            manager.UpdateSession(&packets.PacketSessionData{Header:header,TrackID:0,TrackLength:5002,SessionType:10})
            feed:=func(h packets.PacketHeader,lap uint8,dist float32){
                laps:=&packets.PacketLapData{Header:h}
                laps.LapData[0]=packets.LapData{CurrentLapNum:lap,LapDistance:dist,CarPosition:1}
                manager.UpdateLapData(laps)
                motion:=&packets.PacketMotionData{Header:h}
                motion.CarMotionData[0].WorldPositionX=dist
                motion.CarMotionData[0].WorldPositionZ=dist/5
                manager.UpdateMotion(motion,0)
            }
            for i:=0;i<=100;i++{feed(header,2,2+float32(i)*5)}
            header.SessionUID=test.nextUID
            if test.nextUID!=1{manager.UpdateSession(&packets.PacketSessionData{Header:header,TrackID:test.nextTrack,TrackLength:6000,SessionType:10})}
            feed(header,1,test.nextDist)
            after,err:=os.ReadFile(path);if err!=nil{t.Fatal(err)}
            points:=store.Get(0).Points
            if bytes.Equal(before,after)||len(points)!=101{t.Fatalf("expected independently verified corruption, got %d points",len(points))}
            t.Logf("normal PM UpdateSession/UpdateLapData/UpdateMotion calls: UID=%d track=%d old Australia map bytes=%d -> %d points=501 -> %d",test.nextUID,test.nextTrack,len(before),len(after),len(points))
        })
    }
}
