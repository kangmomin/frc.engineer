package analysis

import (
	"io"
	"log/slog"
	"os"
	"path/filepath"
	"testing"

	"frc.engineer/internal/packets"
	"frc.engineer/internal/udp"
)

func auditPacketLogs(t *testing.T, laps []packets.LapData, times []float32, statuses []packets.CarStatusData, statusTimes []float32) string {
	t.Helper()
	base := t.TempDir()
	pl := udp.NewPacketLogger(base, slog.New(slog.NewTextHandler(io.Discard, nil)))
	for i, lap := range laps {
		h := packets.PacketHeader{PacketFormat: 2026, SessionUID: 1, SessionTime: times[i], PacketID: packets.PacketIDLapData, PlayerCarIndex: 0}
		p := &packets.PacketLapData{Header: h}
		p.LapData[0] = lap
		pl.Log(&h, &udp.ParsedData{Header: &h, LapData: p}, []byte{1})
	}
	for i, status := range statuses {
		h := packets.PacketHeader{PacketFormat: 2026, SessionUID: 1, SessionTime: statusTimes[i], PacketID: packets.PacketIDCarStatus, PlayerCarIndex: 0}
		p := &packets.PacketCarStatusData{Header: h}
		p.CarStatusData[0] = status
		pl.Log(&h, &udp.ParsedData{Header: &h, CarStatus: p}, []byte{1})
	}
	pl.Close()
	dirs, err := os.ReadDir(base)
	if err != nil || len(dirs) != 1 { t.Fatalf("session directory: %v / %d", err, len(dirs)) }
	return filepath.Join(base, dirs[0].Name())
}

func TestAuditAnalysisInvalidLapDoesNotBecomeBest(t *testing.T) {
	dir := auditPacketLogs(t, []packets.LapData{
		{CurrentLapNum: 1, CurrentLapInvalid: 1, Sector: 2},
		{CurrentLapNum: 2, LastLapTimeInMS: 80000},
		{CurrentLapNum: 2, CurrentLapInvalid: 0, Sector: 2},
		{CurrentLapNum: 3, LastLapTimeInMS: 90000},
	}, []float32{79, 80, 169, 170}, nil, nil)
	result, err := Analyze(dir)
	if err != nil { t.Fatal(err) }
	if len(result.Laps) != 2 { t.Fatalf("laps: %+v", result.Laps) }
	bestNum, bestTime := fastestLap(result.Laps)
	t.Logf("first lap invalid input=1; analysis valid=%v; best lap=%d time=%d", result.Laps[0].Valid, bestNum, bestTime)
	if result.Laps[0].Valid || bestNum != 2 || bestTime != 90000 { t.Fatal("invalid lap promoted to analysis best") }
}

func TestAuditAnalysisPreservesCompletedSectors(t *testing.T) {
	dir := auditPacketLogs(t, []packets.LapData{
		{CurrentLapNum: 1, Sector: 2, Sector1TimeInMS: 10000, Sector1TimeMinutes: 1, Sector2TimeInMS: 40000},
		{CurrentLapNum: 2, LastLapTimeInMS: 150000, Sector: 0},
	}, []float32{149, 150}, nil, nil)
	result, err := Analyze(dir)
	if err != nil { t.Fatal(err) }
	if len(result.Laps) != 1 { t.Fatalf("laps: %+v", result.Laps) }
	got := result.Laps[0]
	t.Logf("recorded sectors 70000/40000/40000; analysis=%d/%d/%d", got.Sector1Ms, got.Sector2Ms, got.Sector3Ms)
	if got.Sector1Ms != 70000 || got.Sector2Ms != 40000 || got.Sector3Ms != 40000 { t.Fatal("completed sector times lost at new lap") }
}

func TestAuditAnalysisTyresFollowRecordedLapTime(t *testing.T) {
	dir := auditPacketLogs(t, []packets.LapData{
		{CurrentLapNum: 1},
		{CurrentLapNum: 2, LastLapTimeInMS: 90000},
		{CurrentLapNum: 3, LastLapTimeInMS: 90000},
		{CurrentLapNum: 4, LastLapTimeInMS: 90000},
	}, []float32{0, 90, 180, 270}, []packets.CarStatusData{
		{VisualTyreCompound: 16, TyresAgeLaps: 0},
		{VisualTyreCompound: 16, TyresAgeLaps: 1},
		{VisualTyreCompound: 16, TyresAgeLaps: 2},
		{VisualTyreCompound: 17, TyresAgeLaps: 0},
		{VisualTyreCompound: 17, TyresAgeLaps: 1},
		{VisualTyreCompound: 17, TyresAgeLaps: 2},
	}, []float32{0, 90, 179, 180, 270, 359})
	result, err := Analyze(dir)
	if err != nil { t.Fatal(err) }
	if len(result.Laps) != 3 { t.Fatalf("laps: %+v", result.Laps) }
	t.Logf("recording Soft lap1-2 then Medium lap3; analysis=%s/%s/%s; stints=%+v", result.Laps[0].Compound, result.Laps[1].Compound, result.Laps[2].Compound, result.Stints)
	if result.Laps[1].Compound != "Soft" { t.Fatal("future replacement tyre assigned to pre-pit lap") }
}

func TestAuditSessionsSortedByTimestamp(t *testing.T) {
	base := t.TempDir()
	for _, name := range []string{"9_20260101_000000", "1_20260905_000000"} {
		dir := filepath.Join(base, name)
		if err := os.MkdirAll(dir, 0755); err != nil { t.Fatal(err) }
		if err := os.WriteFile(filepath.Join(dir, "lap_data.jsonl"), []byte("{}\n"), 0644); err != nil { t.Fatal(err) }
	}
	sessions, err := ListSessions(base)
	if err != nil { t.Fatal(err) }
	t.Logf("session order=%s, %s", sessions[0].Timestamp, sessions[1].Timestamp)
	if sessions[0].Timestamp != "20260905_000000" { t.Fatal("newest session is not first") }
}
