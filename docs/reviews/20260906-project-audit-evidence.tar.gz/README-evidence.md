# v4.53.0 추가 감사 재현 자료

기준 소스: `/workspace/frc.engineer`, commit `84790bf5b7a8ae12c1706ed9a8d98ef9e79b70ef`.
감사 실행: 2026-09-05~06. 제품 소스는 수정하지 않았다.

`pitwall/repro-results.json`은 실제 Chrome에서 관찰한 값이다. `execution-results.json`은
도구 실행 결과를 정리한 기록이고, 원본 의존성 감사 JSON은 별도로 포함했다.
`database-test-summary.json`은 격리 PostgreSQL에서 통과한 테스트 이름·개수다.
운영 DB나 실제 사용자 파일은 포함하지 않았다. `udp-test.log`는 최초 processor 검사에서
관측한 무한 루프의 SIGQUIT 스택이며 통과 로그가 아니다.

## 재현 준비

압축을 새 임시 디렉터리에 풀고, 그 안에서 `python3 prepare.py /path/to/frc.engineer`를
실행하면 overlay와 브라우저 하네스의 경로를 현재 checkout/압축 해제 위치에 맞춘다.
prepare.py는 압축을 푼 자료의 경로만 바꾼다. 이후 아래 명령은 checkout에서 실행한다.
`AUDIT_REPRO_ROOT`는 압축을 푼 자료 디렉터리의 절대 경로다.

Go 환경 및 프로젝트 의존성이 필요하다. 브라우저 재현에는 Node 22 이상,
`google-chrome`, checkout의 `web/node_modules`(React/esbuild)가 필요하다.
Sender package 검사는 평소처럼 go:embed용 web 빌드도 필요할 수 있다.

```bash
go test -overlay "$AUDIT_REPRO_ROOT/analysis-overlay.json" ./internal/analysis -run '^TestAudit' -count=1 -v -timeout=10s
go test -overlay "$AUDIT_REPRO_ROOT/yaw-overlay.json" ./internal/telemetry -run '^TestAuditOneMotion' -count=1 -v -timeout=5s
go test -overlay "$AUDIT_REPRO_ROOT/replay-timer-overlay.json" ./internal/telemetry -run '^TestAuditReplayPreservesSessionCountdown$' -count=1 -v -timeout=10s
go test -overlay "$AUDIT_REPRO_ROOT/track-overlay.json" ./internal/telemetry -run '^TestAuditTrackRecorderPreservesMapAtBoundary$' -count=1 -v -timeout=10s
go test -overlay "$AUDIT_REPRO_ROOT/pitwall/track-callpath-overlay.json" ./internal/telemetry -run '^TestAuditTrackBoundaryViaPitwallManager$' -count=1 -v -timeout=10s
go test -overlay "$AUDIT_REPRO_ROOT/pitwall/go-overlay.json" ./internal/telemetry -run '^TestAuditInvalidQualifyingLapDTO$' -count=1 -v -timeout=10s
go test -overlay "$AUDIT_REPRO_ROOT/latest-overlay.json" ./cmd/sender -run '^TestAuditLatestRacePayload$' -count=1 -v -timeout=10s
go test -overlay "$AUDIT_REPRO_ROOT/parser-overlay.json" ./internal/udp -run '^TestAuditParserRandomWireInputs$' -count=1 -v -timeout=10s
node "$AUDIT_REPRO_ROOT/pitwall/run-browser.mjs"
```

## 결과 해석

- analysis, yaw, replay-timer, track, latest 불변식 검사는 기준 HEAD에서 **실패**해야 관측 결과와 일치한다.
- track-callpath와 invalid qualifying DTO 검사는 **문제가 되는 출력이 실제로 발생함을 확인**하므로 기준 HEAD에서 통과한다. 수정 후의 정상 동작 검사로 그대로 쓰면 안 된다.
- 브라우저 하네스도 관측한 버그를 확인하고 JSON을 쓴다. exit 0이 제품 무결성을 뜻하지 않는다. 오디오 에너지 수치는 환경에 따라 달라질 수 있다.
- parser 검사는 파서까지만 호출한다. 처리기 전체의 정상 종료를 보증하지 않는다.
- `udp_audit_test.go`/`udp-overlay.json`은 최초 중단된 processor 탐색의 보존 자료다. 기본 재현 목록에서 제외했다. 실행한다면 반드시 `go test -timeout`을 지정한다.
- latest 핸들러는 기준 HEAD의 본문을 그대로 추출한 fixture다. 이후 핸들러 수정 검증용으로는 실제 새 핸들러와 연결하도록 바꿔야 한다.
- DB 검사는 `PLATFORM_TEST_DATABASE_URL`, `PLATFORM_UPGRADE_TEST_DATABASE_URL`의 별도 임시 DB에서 수행했다. 이 테스트는 데이터를 비우고 schema를 재생성하므로 공유·운영 DB로 실행하지 않는다.
- `govulncheck -json`의 exit 0은 취약점 없음이 아니다. raw JSON은 JSONL처럼 한 줄씩 읽는 형식이 아니라 여러 pretty JSON 객체가 이어지는 형식이다.

현재 코드·런타임·의존성이 달라지면 결과도 달라질 수 있다. 이 묶음은 현재 회귀 테스트에 자동으로 추가되지 않는다.
