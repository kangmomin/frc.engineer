package main
import (
 "encoding/json"
 "io"
 "log/slog"
 "net/http"
 "net/http/httptest"
 "sync"
 "testing"
 "time"
 "frc.engineer/internal/races"
 "frc.engineer/internal/telemetry"
 "frc.engineer/internal/packets"
)
func auditRegisterLatest(mux *http.ServeMux, latestRaceSummary *races.RaceSummary) {
 var raceSummaryMu sync.RWMutex
 var cfgMu sync.Mutex
 var raceStorage *races.FileStorage
 logger := slog.New(slog.NewTextHandler(io.Discard,nil))
	mux.HandleFunc("GET /api/races/latest", func(w http.ResponseWriter, r *http.Request) {
		raceSummaryMu.RLock()
		summary := latestRaceSummary
		raceSummaryMu.RUnlock()
		if summary != nil {
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(stripPrivateCapture(summary))
			return
		}

		cfgMu.Lock()
		rs := raceStorage
		cfgMu.Unlock()
		if rs == nil {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusNotFound)
			json.NewEncoder(w).Encode(map[string]string{"error": "race summary not found"})
			return
		}

		list, err := rs.List()
		if err != nil {
			logger.Error("failed to list race summaries", "error", err)
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusInternalServerError)
			json.NewEncoder(w).Encode(map[string]string{"error": "failed to load race summary"})
			return
		}
		if len(list) == 0 {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusNotFound)
			json.NewEncoder(w).Encode(map[string]string{"error": "race summary not found"})
			return
		}

		loaded, err := rs.Load(list[0].ID)
		if err != nil {
			logger.Error("failed to load latest race summary", "id", list[0].ID, "error", err)
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusInternalServerError)
			json.NewEncoder(w).Encode(map[string]string{"error": "failed to load race summary"})
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(stripPrivateCapture(loaded))
	})

}
func TestAuditLatestRacePayload(t *testing.T) {
 h:=packets.PacketHeader{SessionUID:453, PacketFormat:2026}
 pm:=telemetry.NewPitwallManager(telemetry.NewStrategyManager(),nil,nil)
 pm.UpdateSession(&packets.PacketSessionData{Header:h,SessionType:15,TotalLaps:57,TrackLength:5400,TrackID:7})
 parts:=&packets.PacketParticipantsData{Header:h,NumActiveCars:24}
 laps:=&packets.PacketLapData{Header:h}
 tel:=&packets.PacketCarTelemetryData{Header:h}
 status:=&packets.PacketCarStatusData{Header:h}
 for i:=0;i<24;i++ {
  copy(parts.Participants[i].Name[:], "Recorded Driver")
  parts.Participants[i].YourTelemetry=1
  parts.Participants[i].TeamID=uint16(i%11)
  laps.LapData[i].CarPosition=uint8(i+1)
  laps.LapData[i].CurrentLapNum=30
  laps.LapData[i].CurrentLapTimeInMS=45000
  laps.LapData[i].LastLapTimeInMS=92345
  laps.LapData[i].ResultStatus=2
  tel.CarTelemetryData[i].Speed=280
  status.CarStatusData[i].ERSStoreEnergy=3300000
  status.CarStatusData[i].VisualTyreCompound=17
 }
 pm.UpdateParticipants(parts);pm.UpdateLapData(laps);pm.UpdateCarStatus(status);pm.UpdateTelemetry(tel)
 state:=pm.BuildReplayState()
 summary:=races.BuildSummary(453,state,races.NotificationCounts{},nil,nil,time.Now())
 summary.Replay=&races.ReplayTimeline{FrameIntervalMS:500}
 for i:=0;i<240;i++ { summary.Replay.Frames=append(summary.Replay.Frames,races.ReplayFrame{Timestamp:int64(1000+i*500),Pitwall:state}) }
 mux:=http.NewServeMux();auditRegisterLatest(mux,summary)
 rr:=httptest.NewRecorder();start:=time.Now();mux.ServeHTTP(rr,httptest.NewRequest("GET","/api/races/latest",nil));duration:=time.Since(start)
 var fields map[string]json.RawMessage
 if err:=json.Unmarshal(rr.Body.Bytes(),&fields);err!=nil{t.Fatal(err)}
 lean:=*summary;lean.Replay=nil
 small,_:=json.Marshal(stripPrivateCapture(&lean))
 t.Logf("120 seconds, 24 cars: latest response bytes=%d; without Replay=%d; encode=%s; 60min linear estimate=%.1f MiB/request",rr.Body.Len(),len(small),duration,float64(rr.Body.Len()*30)/(1024*1024))
 if len(fields["replay"])>0 {t.Fatal("3-second latest-result polling endpoint returns complete replay")}
}
