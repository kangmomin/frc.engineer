package telemetry

import (
	"bytes"
	"io"
	"log/slog"
	"os"
	"path/filepath"
	"testing"

	"frc.engineer/internal/tracks"
)

func TestAuditTrackRecorderPreservesMapAtBoundary(t *testing.T) {
	logger := slog.New(slog.NewTextHandler(io.Discard, nil))
	previous := slog.Default()
	slog.SetDefault(logger)
	t.Cleanup(func() { slog.SetDefault(previous) })
	for _, tc := range []struct {
		name string
		nextTrack int8
		nextDistance float32
	}{
		{"flashback_to_previous_lap", 0, 3000},
		{"new_track_lap_one", 3, 2},
	} {
		t.Run(tc.name, func(t *testing.T) {
			dir := t.TempDir()
			store := tracks.NewTrackStore(dir)
			r := NewTrackRecorder(dir, store, logger)
			full := make([]recordPoint, 501)
			for i := range full {
				full[i] = recordPoint{Dist: 2 + float32(i)*10, X: float32(i), Z: float32(i%20)}
			}
			r.saveLap(0, "Australia", full)
			path := filepath.Join(dir, tracks.TrackStorageKey(0)+"_recorded.txt")
			before, err := os.ReadFile(path)
			if err != nil { t.Fatal(err) }
			r.SetEnabled(true)
			for i := 0; i <= 100; i++ {
				d := 2 + float32(i)*5
				r.RecordPoint(0, "Australia", d, 2, d, 0, d/5, 0, 0)
			}
			r.RecordPoint(tc.nextTrack, tracks.TrackName(tc.nextTrack), tc.nextDistance, 1, 0, 0, 0, 0, 0)
			after, err := os.ReadFile(path)
			if err != nil { t.Fatal(err) }
			if !bytes.Equal(before, after) {
				t.Fatalf("incomplete 502m lap overwrote 5002m recorded map: points=%d -> %d, bytes=%d -> %d", len(full), len(store.Get(0).Points), len(before), len(after))
			}
		})
	}
}
