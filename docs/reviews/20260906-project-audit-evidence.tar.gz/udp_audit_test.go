package telemetry

import (
	"encoding/binary"
	"math/rand"
	"testing"

	"frc.engineer/internal/udp"
	"frc.engineer/internal/websocket"
)

func TestAuditUDPInputsDoNotPanic(t *testing.T) {
	logger := testLogger()
	p := NewProcessor(udp.NewParser(logger), websocket.NewHub(8, logger), 0, logger, nil)
	rng := rand.New(rand.NewSource(453))
	for i := 0; i < 5000; i++ {
		size := 2048
		if i%2 == 0 { size = rng.Intn(2049) }
		data := make([]byte, size)
		_, _ = rng.Read(data)
		if size >= 29 {
			binary.LittleEndian.PutUint16(data, uint16(2025+i%2))
			data[6] = byte((i/2)%17)
			binary.LittleEndian.PutUint64(data[7:15], 453)
			binary.LittleEndian.PutUint32(data[15:19], 0)
		}
		func() {
			defer func() { if recovered := recover(); recovered != nil { t.Fatalf("panic case=%d size=%d packet=%d: %v", i, size, data[6], recovered) } }()
			p.processPacket(data)
		}()
	}
	t.Log("processed 5000 deterministic short/random payloads across 17 packet IDs without panic")
}
