package telemetry

import (
	"testing"
	"frc.engineer/internal/dto"
)

func TestAuditReplayPreservesSessionCountdown(t *testing.T) {
	source := &dto.PitwallState{Session:&dto.SessionInfo{SessionType:"Q1", SessionTimeLeft:600,SessionDuration:1080}}
	frame := copyPitwallForReplay(source)
	meta := copySessionInfo(source.Session)
	t.Logf("live left/duration=600/1080; frame=%d/%d; meta=%d/%d", frame.Session.SessionTimeLeft,frame.Session.SessionDuration,meta.SessionTimeLeft,meta.SessionDuration)
	if frame.Session.SessionTimeLeft != 600 || meta.SessionDuration != 1080 {t.Fatal("qualifying replay loses countdown and session duration")}
}
