"""Relocate extracted audit evidence; never writes checkout files."""
import json
from pathlib import Path
import sys

evidence = Path(__file__).resolve().parent
checkout = Path(sys.argv[1]).resolve()
if not (checkout / "go.mod").is_file():
    raise SystemExit("Pass the frc.engineer checkout path")

original_checkout = "/workspace/frc.engineer"
original_evidence = "/tmp/frc-full-audit-a11yogpw"
paths = [*evidence.glob("*-overlay.json"), evidence / "pitwall/go-overlay.json",
         evidence / "pitwall/track-callpath-overlay.json",
         evidence / "pitwall/repro.browser.tsx", evidence / "pitwall/run-browser.mjs"]
for path in set(paths):
    text = path.read_text().replace(original_checkout, str(checkout)).replace(original_evidence, str(evidence))
    path.write_text(text)
    if path.suffix == ".json":
        for source in json.loads(text)["Replace"].values():
            if not Path(source).is_file():
                raise SystemExit(f"Missing overlay source: {source}")
print(f"Checkout: {checkout}")
print(f"AUDIT_REPRO_ROOT={evidence}")
print("See README-evidence.md for commands and expected failures.")
